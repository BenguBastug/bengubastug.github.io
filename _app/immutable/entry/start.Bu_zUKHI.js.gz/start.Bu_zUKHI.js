import{a as t}from"../chunks/entry.BNK5tN9w.js";export{t as start};
