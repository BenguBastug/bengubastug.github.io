import{a as t}from"../chunks/entry.BIYbGKFj.js";export{t as start};
