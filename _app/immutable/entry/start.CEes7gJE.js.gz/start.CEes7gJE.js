import{a as t}from"../chunks/entry.C5Pl1qWB.js";export{t as start};
