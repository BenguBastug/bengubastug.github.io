import{a as t}from"../chunks/entry.CGnyHBi-.js";export{t as start};
