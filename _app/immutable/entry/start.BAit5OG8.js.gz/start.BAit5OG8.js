import{a as t}from"../chunks/entry.CcuRNYfX.js";export{t as start};
