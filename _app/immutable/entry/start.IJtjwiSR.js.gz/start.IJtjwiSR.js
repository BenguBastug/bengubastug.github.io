import{a as t}from"../chunks/entry.Dmc0aLdJ.js";export{t as start};
