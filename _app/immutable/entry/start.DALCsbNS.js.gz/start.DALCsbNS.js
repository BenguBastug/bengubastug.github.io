import{a as t}from"../chunks/entry.Chi9Ox6o.js";export{t as start};
