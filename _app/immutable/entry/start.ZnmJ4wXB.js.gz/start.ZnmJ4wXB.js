import{a as t}from"../chunks/entry.DJdFMz1k.js";export{t as start};
