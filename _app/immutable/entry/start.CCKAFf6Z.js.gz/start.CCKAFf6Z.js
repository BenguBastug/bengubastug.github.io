import{a as t}from"../chunks/entry.yiax6Dpk.js";export{t as start};
