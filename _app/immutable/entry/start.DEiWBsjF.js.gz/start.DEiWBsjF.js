import{a as t}from"../chunks/entry.TC2o-ZgJ.js";export{t as start};
