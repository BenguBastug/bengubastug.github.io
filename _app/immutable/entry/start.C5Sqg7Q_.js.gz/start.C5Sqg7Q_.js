import{a as t}from"../chunks/entry.JT41MQpM.js";export{t as start};
