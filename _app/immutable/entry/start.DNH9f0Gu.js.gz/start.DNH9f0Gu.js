import{a as t}from"../chunks/entry.CGryDeGc.js";export{t as start};
