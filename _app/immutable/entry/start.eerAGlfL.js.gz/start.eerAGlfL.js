import{a as t}from"../chunks/entry.BiUxLa67.js";export{t as start};
