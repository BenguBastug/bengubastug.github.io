import{a as t}from"../chunks/entry.Bx7dNwtA.js";export{t as start};
