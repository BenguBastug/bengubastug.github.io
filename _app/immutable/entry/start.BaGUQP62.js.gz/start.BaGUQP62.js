import{a as t}from"../chunks/entry.CgtVb-gG.js";export{t as start};
