import{a as t}from"../chunks/entry.CDxeMad-.js";export{t as start};
