import{a as t}from"../chunks/entry.C2WjYLug.js";export{t as start};
