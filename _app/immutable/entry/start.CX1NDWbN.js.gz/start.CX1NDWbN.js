import{a as t}from"../chunks/entry.DT79Q64a.js";export{t as start};
