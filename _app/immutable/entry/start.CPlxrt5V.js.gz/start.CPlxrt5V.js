import{a as t}from"../chunks/entry.Or3Yzb0I.js";export{t as start};
