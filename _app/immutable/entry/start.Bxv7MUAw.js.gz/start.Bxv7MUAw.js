import{a as t}from"../chunks/entry.HBWAnYE2.js";export{t as start};
