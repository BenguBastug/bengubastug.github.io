import{a as t}from"../chunks/entry.D5pdpTXx.js";export{t as start};
