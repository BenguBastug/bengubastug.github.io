import{a as t}from"../chunks/entry.DNn59Fxb.js";export{t as start};
