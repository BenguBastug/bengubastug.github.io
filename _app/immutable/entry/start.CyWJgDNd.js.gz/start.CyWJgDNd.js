import{a as t}from"../chunks/entry.D3zRsv_m.js";export{t as start};
